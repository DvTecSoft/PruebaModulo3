-- Creo base de datos
create database alkewallet_dvidal;

-- Selecciono base de datos
use alkewallet_dvidal;

-- Creo tablas 
Create Table usuario
(
 	 user_id int auto_increment not null
	,nombre varchar(50) not null
	,correo_electronico varchar(100) not null 
	,contrase�a varchar(255) not null
	,saldo float
	,Primary Key (user_id, correo_electronico)
);

Create Table moneda
(
	 currency_id int auto_increment not null
	,currency_name varchar(20) not null
	,currency_symbol varchar(5) not null	
	,Primary Key (currency_id, currency_symbol)
);

Create Table transaccion
(
 	 transaction_id int auto_increment  not null
	,sender_user_id int not null
	,receiver_user_id int not null 
	,importe float not null
	,transaction_date date
	,currency_id int not null
	,PRIMARY KEY (transaction_id)
	,FOREIGN KEY (sender_user_id) 	REFERENCES usuario(user_id)
	,FOREIGN KEY (receiver_user_id) REFERENCES usuario(user_id)
	,FOREIGN KEY (currency_id) 			REFERENCES moneda(currency_id)
);

-- Agrega informaci�n
Insert Into usuario Values 
 (0, "Daniel"	,	"daniel@gmail.com", 	SHA2('123', 256)		,100000)
,(0, "Johanna", "johanna@gmail.com", 	SHA2('456', 256)		,200000)
,(0, "Barbara", "barbara@gmail.com", 	SHA2('789', 256)		,300000)
,(0, "Josue"	,	"josue@gmail.com", 		SHA2('101112', 256)	,400000)
,(0, "Juan"		,	"juan@gmail.com", 		SHA2('131415', 256)	,500000);

Insert Into moneda Values 
 (0, 'Pesos', 'CLP')
,(0, 'Dolar', 'USD')
,(0, 'Euro'	, 'EUR')
,(0, 'Yuan', 'CNY')
,(0, 'Franco', 'CHF');

Insert Into transaccion Values
 (0, 1, 2, 1000, date(now()), 1)
,(0, 1, 3, 2000, date(now()), 2)
,(0, 1, 4, 3000, date(now()), 3)
,(0, 1, 5, 4000, date(now()), 4);

Insert Into transaccion Values
 (0, 2, 1, 1000, date(now()), 5)
,(0, 2, 3, 2000, date(now()), 1)
,(0, 2, 4, 3000, date(now()), 2)
,(0, 2, 5, 4000, date(now()), 3);

Insert Into transaccion Values
 (0, 3, 1, 1000, date(now()), 1)
,(0, 3, 2, 2000, date(now()), 2)
,(0, 3, 4, 3000, date(now()), 3)
,(0, 3, 5, 4000, date(now()), 4);

Insert Into transaccion Values
 (0, 4, 1, 1000, date(now()), 5)
,(0, 4, 2, 2000, date(now()), 1)
,(0, 4, 3, 3000, date(now()), 1)
,(0, 4, 5, 4000, date(now()), 2);

Insert Into transaccion Values
 (0, 5, 1, 1000, date(now()), 1)
,(0, 5, 2, 2000, date(now()), 2)
,(0, 5, 3, 3000, date(now()), 3)
,(0, 5, 4, 4000, date(now()), 2);


-- 1.- Consulta para obtener el nombre de la moneda elegida por un usuario espec�fico
Select currency_name as nombre_moneda from moneda where currency_symbol = 'CLP';

-- 2.- Consulta para obtener las transacciones realizadas por un usuario espec�fico
Select 
	 t.transaction_id
	,u.nombre 	as UsuarioRealiza
	,ur.nombre 	as UsuarioRecibe
	,t.importe 	as Monto
	,t.transaction_date as FechaTransaccion
From
	usuario as u
Left Join	
	transaccion as t
On
	u.user_id = t.sender_user_id
Left Join
	usuario as ur
On
	t.receiver_user_id = ur.user_id
Where
	u.correo_electronico = 'daniel@gmail.com';
	
-- 3.- Consulta para obtener todos los usuarios registrados
Select 
	*
From
	usuario;
	
-- 4.- Consulta para obtener todas las monedas registradas
Select 
	*
From
	moneda;

-- 5.- Consulta para obtener todas las transacciones registradas
Select 
	*
From
	transaccion;

-- 6.- Consulta para obtener todas las transacciones realizadas por un usuario espec�fico
Select 
	 t.transaction_id
	,u.nombre 	as UsuarioRealiza
	,ur.nombre 	as UsuarioRecibe
	,t.importe 	as Monto
	,t.transaction_date as FechaTransaccion
From
	usuario as u
Left Join	
	transaccion as t
On
	u.user_id = t.sender_user_id
Left Join
	usuario as ur
On
	t.receiver_user_id = ur.user_id
Where
	u.correo_electronico = 'daniel@gmail.com';

-- 7.- Consulta para obtener todas las transacciones recibidas por un usuario espec�fico
Select 
	 t.transaction_id
	,u.nombre 	as UsuarioRecibe
	,ur.nombre 	as UsuarioRealiza
	,t.importe 	as Monto
	,t.transaction_date as FechaTransaccion
From
	usuario as u
Left Join	
	transaccion as t
On
	u.user_id = t.receiver_user_id
Left Join
	usuario as ur
On
	t.sender_user_id = ur.user_id
Where
	u.correo_electronico = 'daniel@gmail.com';

-- 8.- Sentencia DML para modificar el campo correo electr�nico de un usuario espec�fico
Update 
	usuario
Set 
	correo_electronico = 'daniel2@gmail.com'
Where
	correo_electronico = 'daniel@gmail.com';

-- 9.- Sentencia para eliminar los datos de una transacci�n (eliminado de la fila completa)
-- -- Compruebo si tengo el registro a eliminar
-- Select 
-- 	*
-- From
-- 	transaccion
-- Where
-- 		sender_user_id = 1
-- and receiver_user_id = 2;

-- Elimino registro
Delete from
	transaccion
Where
		sender_user_id 		= 1
and receiver_user_id 	= 2;

-- 10.- Sentencia para DDL modificar el nombre de la columna correo_electronico por email
Alter Table usuario CHANGE correo_electronico email varchar(255);
